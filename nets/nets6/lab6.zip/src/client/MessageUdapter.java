package client;

/**
 * Created by vikacech on 11/30/17.
 */
public class MessageUdapter {


//    public class MessageUpdater implements ValueChangedHandler {
//            @Override
//            public void handle(Object value) {
//                if (value != null) {
//                    messageArea.append(value.toString() + "\n");
//                    messageArea.setCaretPosition(messageArea.getText().length() - 1);
//                }
//
//            }
//        }
}
