package client;

public interface ValueChangedHandler {
    void handle(Object value);
}
