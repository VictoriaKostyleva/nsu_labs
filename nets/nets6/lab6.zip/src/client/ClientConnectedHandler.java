package client;

public interface ClientConnectedHandler {
    void handle(boolean isConnected);
}