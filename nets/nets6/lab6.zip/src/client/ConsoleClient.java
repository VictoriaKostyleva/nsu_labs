package client;

import server.Server;

import java.util.Scanner;


public class ConsoleClient {

    private Client client;

    public ConsoleClient(Client client) {
        this.client = client;
    }

    public void startWork(String[] args){
        Client client = new Client();

        if (!client.isLoggedIn()) {
            try {

                client.setServer(args[0]);
                int port = Integer.parseInt(args[1]);
                checkPortNumber(port);
                client.setPort(port);
                client.setUsername(args[1]);
                client.startWork();
//                addClientConnectedHandler();
            } catch (NumberFormatException e) {
                System.out.println("try again");
            }
        }

      try (Scanner in = new Scanner(System.in)) {
//            while(client.isLoggedIn()) {
          while (true) {
                String text = in.nextLine();
                if(text.equals("/logout")) {
                    client.sendLogoutMessage();
                }
                else {
                    if (text.equals("/others")) {
                        client.sendUserListMessage();
                    } else {
                        client.sendTextMessage(text);
                    }
                }

            }
      }

    }


    private void checkPortNumber(int portNumber) throws NumberFormatException {
        if ((portNumber < Server.MIN_PORT_NUMBER) || (portNumber > Server.MAX_PORT_NUMBER)) {
            throw new NumberFormatException("Incorrect value");
        }
        client.setPort(portNumber);
    }

    public class MessageUpdater implements ValueChangedHandler {
        @Override
        public void handle(Object value) {
            if (value != null) {
                System.out.println(value + "/n");
            }

        }
    }

    private void addClientConnectedHandler() {
        System.out.println("lololol");
    }


}
