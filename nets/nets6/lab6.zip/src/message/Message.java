package message;

public abstract class Message {
}
